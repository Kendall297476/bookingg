<?php
session_start(); // Start the session

// Log session data for debugging
error_log('Session Data in success.php: ' . print_r($_SESSION, true));

require 'vendor/autoload.php';  // Load the Stripe library

\Stripe\Stripe::setApiKey('sk_test_51LbpIsRT3MjYCnBGVTSBbGH69ZbLpiRI3u8ZH5YNDG1Ny7JXaUXJVsGWPa3FXCm4DIaPYtETjzHuzZCGlUW4dTRn00A0F0xnaF');

$session_id = $_GET['session_id'] ?? null;

if (!$session_id) {
    echo "Session ID is missing.";
    exit;
}

try {
    $session = \Stripe\Checkout\Session::retrieve($session_id);

    if ($session->payment_status === 'paid') {
        // Prepare data to insert into the database
        $fullname = $_SESSION['fullname'] ?? '';
        $email = $_SESSION['email'] ?? '';
        $phone = $_SESSION['phone'] ?? '';
        $item = $_SESSION['item'] ?? ''; // Retrieve the item data
        $item_number = $_SESSION['item_number'] ?? ''; // Retrieve the item number
        $pickup_location = $_SESSION['pickup_location'] ?? '';
        $delivery_location = $_SESSION['delivery_location'] ?? '';
        $date = $_SESSION['date'] ?? '';
        $specific_time = $_SESSION['specific_time'] ?? ''; // Retrieve the specific time
        $distance = $_SESSION['distance'] ?? '';
        $cost = $_SESSION['cost'] ?? 0;

        // Database configuration
        $servername = "localhost";
        $username = "uvwjwzmy_wp1077";
        $password = "h62@34.p3S";
        $dbname = "uvwjwzmy_wp1077";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            error_log("Connection failed: " . $conn->connect_error);
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert data into the database
        $stmt = $conn->prepare("INSERT INTO deliveries (fullname, email, phone, item, item_number, pickup_location, delivery_location, date, specific_time, distance, cost) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssddsss", $fullname, $email, $phone, $item, $item_number, $pickup_location, $delivery_location, $date, $specific_time, $distance, $cost);

        if ($stmt->execute()) {
            echo "Payment successful and data has been recorded!";
            
        } else {
            error_log("Database Insert Error: " . $stmt->error);
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "Payment was not successful. Please try again.";
    }
} catch (\Stripe\Exception\ApiErrorException $e) {
    error_log("Stripe API Error: " . htmlspecialchars($e->getMessage()));
    echo "Error: " . htmlspecialchars($e->getMessage());
} catch (Exception $e) {
    error_log("Unexpected Error: " . htmlspecialchars($e->getMessage()));
    echo "An unexpected error occurred: " . htmlspecialchars($e->getMessage());
}


?>
