<?php
session_start(); // Start the session

require 'vendor/autoload.php';  // Load the Stripe library

// Database configuration
$servername = "localhost";
$username = "uvwjwzmy_wp1077";
$password = "h62@34.p3S";
$dbname = "uvwjwzmy_wp1077";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve and sanitize form data
$fullname = filter_var($_POST['fullname'] ?? '', FILTER_SANITIZE_STRING);
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$phone = filter_var($_POST['phone'] ?? '', FILTER_SANITIZE_STRING);
$pickup_location = filter_var($_POST['pickup_location'] ?? '', FILTER_SANITIZE_STRING);
$delivery_location = filter_var($_POST['delivery_location'] ?? '', FILTER_SANITIZE_STRING);
$date = filter_var($_POST['date'] ?? '', FILTER_SANITIZE_STRING);
$distance = filter_var($_POST['distance'] ?? '', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$cost = filter_var($_POST['cost'] ?? 0, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$item = filter_var($_POST['item'] ?? '', FILTER_SANITIZE_STRING); // New field
$item_number = filter_var($_POST['item_number'] ?? '', FILTER_SANITIZE_STRING); // New field
$specific_time = filter_var($_POST['specific_time'] ?? '', FILTER_SANITIZE_STRING); // New field

// Check if cost is a valid number
if (!is_numeric($cost) || $cost <= 0) {
    echo "Invalid cost value.";
    exit();
}

// Prepare and execute the SQL statement
$stmt = $conn->prepare("INSERT INTO deliveries (fullname, email, phone, pickup_location, delivery_location, date, distance, cost, item, item_number, specific_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssddsss", $fullname, $email, $phone, $pickup_location, $delivery_location, $date, $distance, $cost, $item, $item_number, $specific_time);

if ($stmt->execute()) {
    // Store data in session
    $_SESSION['fullname'] = $fullname;
    $_SESSION['email'] = $email;
    $_SESSION['phone'] = $phone;
    $_SESSION['pickup_location'] = $pickup_location;
    $_SESSION['delivery_location'] = $delivery_location;
    $_SESSION['date'] = $date;
    $_SESSION['distance'] = $distance;
    $_SESSION['cost'] = $cost;
    $_SESSION['item'] = $item;
    $_SESSION['item_number'] = $item_number;  // Store item number
    $_SESSION['specific_time'] = $specific_time;  // Store specific time

    // Proceed to Stripe Checkout
    \Stripe\Stripe::setApiKey('sk_test_51LbpIsRT3MjYCnBGVTSBbGH69ZbLpiRI3u8ZH5YNDG1Ny7JXaUXJVsGWPa3FXCm4DIaPYtETjzHuzZCGlUW4dTRn00A0F0xnaF');

    try {
        $checkout_session = \Stripe\Checkout\Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => [
                        'name' => 'Delivery Cost',
                    ],
                    'unit_amount' => intval($cost * 100),  // Convert to smallest currency unit (cents)
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => 'https://autobyte-solution.com/peter/test/success.php?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => 'https://autobyte-solution.com/peter/',
        ]);

        // Redirect to Stripe Checkout
        header("Location: " . $checkout_session->url);
        exit();
    } catch (Exception $e) {
        echo 'Error creating Stripe Checkout session: ' . htmlspecialchars($e->getMessage());
        exit();
    }
} else {
    echo "Error: " . htmlspecialchars($stmt->error);
    exit();
}

$stmt->close();
$conn->close();
?>
