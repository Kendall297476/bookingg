<?php
session_start(); // Start the session

require 'vendor/autoload.php';

// Set your secret API key
\Stripe\Stripe::setApiKey('sk_test_51LbpIsRT3MjYCnBGVTSBbGH69ZbLpiRI3u8ZH5YNDG1Ny7JXaUXJVsGWPa3FXCm4DIaPYtETjzHuzZCGlUW4dTRn00A0F0xnaF');

// Get the input data
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Validate input data
if (!isset($data['amount']) || !is_numeric($data['amount']) || $data['amount'] <= 0) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Invalid amount']);
    exit;
}

// Store user data in session variables
$_SESSION['fullname'] = $data['fullname'] ?? ''; 
$_SESSION['email'] = $data['email'] ?? '';
$_SESSION['phone'] = $data['phone'] ?? '';
$_SESSION['item'] = $data['item'] ?? ''; // Store specific time
$_SESSION['item_number'] = $data['item_number'] ?? ''; // Store item number
$_SESSION['pickup_location'] = $data['pickup_location'] ?? '';
$_SESSION['delivery_location'] = $data['delivery_location'] ?? '';
$_SESSION['date'] = $data['date'] ?? '';
$_SESSION['specific_time'] = $data['specific_time'] ?? ''; // Store item number
$_SESSION['distance'] = $data['distance'] ?? '';
$_SESSION['cost'] = intval($data['amount']); // Store amount as cost

// Convert the amount to integer (Stripe uses the smallest currency unit, e.g., cents)
$amount = intval($data['amount']) * 100; // Convert dollars to cents

try {
    // Create a Stripe Checkout session
    $checkout_session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => 'Delivery Cost',
                ],
                'unit_amount' => $amount, // Amount in cents
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => 'https://autobyte-solution.com/peter/test/success.php?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => 'https://autobyte-solution.com/peter/',
    ]);

    echo json_encode(['id' => $checkout_session->id]);
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'An error occurred: ' . $e->getMessage()]);
}
?>
